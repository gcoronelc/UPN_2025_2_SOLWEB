package pe.edu.upn.educaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducaappApplicationTests {

	@Test
	void contextLoads() {
	}

}
