package pe.edu.upn.educaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducaappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducaappApplication.class, args);
	}

}
